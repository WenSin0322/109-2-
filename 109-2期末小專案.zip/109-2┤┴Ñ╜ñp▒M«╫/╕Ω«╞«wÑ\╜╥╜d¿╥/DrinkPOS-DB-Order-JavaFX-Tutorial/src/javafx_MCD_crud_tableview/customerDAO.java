package javafx_MCD_crud_tableview;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import models.DBConnection;
import models.Order;

/**
 * StudentDAO.java This DAO class provides CRUD database operations for the
 * table student in the database.
 */
public class customerDAO {

    //若在此連線一次，在各個方法中沒有進行連線，若太久沒用資料庫會自動斷線，這就出現問題了。
    //因此，在各個方法中在操作資料之前必須先進行連線
    //在各個方法中在操作資料之前必須先進行取得連線，因為太久沒跟資料庫連線，資料庫會自動斷線，這就出現問題無法進行操作，因此，必須先取得連線。
    //private final Connection conn = DBConnection.getConnection();
    private Connection conn;

    public String getMaxOrderNum() {
        conn = DBConnection.getConnection();
        String maxVal = null;

        String query = "SELECT Max(order_num) as `max_id` FROM `sale_order`";
        //String query = "SELECT Max(order_num) as `max_id` FROM `sale_order`";
        //String query = "SELECT Max(order_num) as `max_id` FROM `sale_order` LIMIT 1";
        try {
            PreparedStatement state = conn.prepareStatement(query);
            ResultSet rset = state.executeQuery();
            while (rset.next()) {
                maxVal = rset.getString("max_id");
            }
        } catch (SQLException ex) {
            System.out.println("資料庫getMaxOrderNum操作異常:" + ex.toString());
        }
        return maxVal;
    }
    
    public List<Order> getAllStudents() {
        conn = DBConnection.getConnection();
        String query = "select * from sale_order";
        List<Order> order_list = new ArrayList();

        try {
            PreparedStatement state
                    = conn.prepareStatement(query);
            ResultSet rset = state.executeQuery();

            while (rset.next()) {
                Order order = new Order();
                order.setOrder_num(rset.getString("order_num"));
                order.setCustomer_name(rset.getString("customer_name"));
                order.setCustomer_address(rset.getString("customer_address"));
                order.setCustomer_phone(rset.getString("customer_phone"));

                order_list.add(order);
            }
        } catch (SQLException ex) {
            System.out.println("getAllstudents異常:" + ex.toString());
        }
        return order_list;
    }

    public boolean add(Order order) {
        conn = DBConnection.getConnection();
        String query = "insert into sale_order(order_num,customer_name,customer_address,customer_phone) VALUES (?,?,?,?)";
        boolean success = false;
        try {
            PreparedStatement state = conn.prepareStatement(query);
            state.setString(1, order.getOrder_num());
            state.setString(2, order.getCustomer_name());
            state.setString(3, order.getCustomer_address());
            state.setString(4, order.getCustomer_phone());

            state.execute();
            //state.executeUpdate();
            success = true;
        } catch (SQLException ex) {
            System.out.println("add異常:" + ex.toString());
        }
        return success;
    }

    public boolean delete(String id) {
        conn = DBConnection.getConnection();
        String query = "delete from order_detail where order_num =?";
        boolean sucess = false;
        try {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, id);
            //statement.execute();
            sucess = statement.executeUpdate() > 0;
            if (sucess) {
                System.out.println("Record deleted successfully.");
            } else {
                System.out.println("Record not found.");
            }
        } catch (SQLException ex) {
            System.out.println("delete異常:\n" + ex.toString());
        }
        conn = DBConnection.getConnection();
        query = "delete from sale_order where order_num =?";
        sucess = false;
        try {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, id);
            //statement.execute();
            sucess = statement.executeUpdate() > 0;
            if (sucess) {
                System.out.println("Record deleted successfully.");
            } else {
                System.out.println("Record not found.");
            }
        } catch (SQLException ex) {
            System.out.println("delete異常:\n" + ex.toString());
        }
        return sucess;
    }

    public void update(Order order) {
        conn = DBConnection.getConnection();
        String query
                = "update sale_order set customer_name=?, customer_address= ?, customer_phone=? where order_num = ?";
        try {
            PreparedStatement state = conn.prepareStatement(query);
            state.setString(1, order.getCustomer_name());//將學號塞入問號編號1的位置
            state.setString(2, order.getCustomer_address());
            state.setString(3, order.getCustomer_phone());
            state.setString(4, order.getOrder_num());

            state.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("update異常:" + ex.toString());
        }
    }

    //選擇特定姓名，輸入正確姓名"孫大毛"或是"孫%"或是"%毛"
    public List<Order> selectByName(String name_str) {
        conn = DBConnection.getConnection();
        boolean success = false;
        List<Order> order_list = new ArrayList();
        //String query = String.format("select * from student where name like '%s%s'", name_str, "%");
        //String query = String.format("select * from student where name like '%s'", name_str);
        String query = "select * from sale_order where customer_name like ?";
        try {
            PreparedStatement state = conn.prepareStatement(query);
            state.setString(1, name_str);

            ResultSet rset = state.executeQuery();
            while (rset.next()) {
                Order order = new Order();
                order.setOrder_num(rset.getString("order_num"));
                order.setCustomer_name(rset.getString("customer_name"));
                order.setCustomer_address(rset.getString("customer_address"));
                order.setCustomer_phone(rset.getString("customer_phone"));
                order_list.add(order);
            }
        } catch (SQLException ex) {
            System.out.println("資料庫selectByName操作異常:" + ex.toString());
        }
        return order_list;
    }

    //選擇某個student_id
    public Order selectByID(String id) {
        conn = DBConnection.getConnection();
        boolean success = false;
        String query = "select * from sale_order where order_num = ?";
        //String query = String.format("select * from student where student_id = '%s'", id);
        Order order = new Order();
        try {
            PreparedStatement state = conn.prepareStatement(query);
            state.setString(1, id);
            ResultSet rset = state.executeQuery();

            while (rset.next()) {
                success = true;
                order.setOrder_num(rset.getString("order_num"));
                order.setCustomer_name(rset.getString("customer_name"));
                order.setCustomer_address(rset.getString("customer_address"));
                order.setCustomer_phone(rset.getString("customer_phone"));
            }
        } catch (SQLException ex) {
            System.out.println("資料庫selectByID操作異常:" + ex.toString());
        }

        if (success) {
            return order;
        } else {
            return null;
        }

    }

    //若是有多個不唯一的student_id，查詢結果可能會有多個，以ArrayList回傳
    public List<Order> selectAllByID(String id) {
        conn = DBConnection.getConnection();
        List<Order> order_list = new ArrayList();
        boolean success = false;
        String query = "select * from sale_order where order_num = ?";
        //String query = String.format("select * from student where student_id = '%s'", id);
        Order order = new Order();
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(0, id);
            ResultSet rset = ps.executeQuery();

            while (rset.next()) {
                success = true;

                 order.setOrder_num(rset.getString("order_num"));
                order.setCustomer_name(rset.getString("customer_name"));
                order.setCustomer_address(rset.getString("customer_address"));
                order.setCustomer_phone(rset.getString("customer_phone"));
                order_list.add(order);
            }
        } catch (SQLException ex) {
            System.out.println("資料庫selectByID操作異常:" + ex.toString());
        }

        if (success) {
            return order_list;
        } else {
            return null;
        }

    }
    /*
    public static void main(String[] args) {

        StudentDAO stdao = new StudentDAO();

        // add a student record
        System.out.println(stdao.add(new Student("109", "Lee", "1234")));
        //delete a record
        System.out.println(stdao.delete("109"));

        // select All
        List<Student> student_list = stdao.getAllStudents();
        for (Student student : student_list) {
            System.out.println(student);
        }

        //new StudentDAO();
        // add a student record
        System.out.println(stdao.add(new Student("u005", "孫大明", "1234")));

        // select name
        List<Student> someStudents;
        //someStudents= stdao.selectByName("孫%");
        someStudents = stdao.selectByName("%明");

        for (Student student : someStudents) {
            System.out.println(student);
        }

        System.out.println(stdao.delete("u005"));

    }*/
}
