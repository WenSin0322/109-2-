/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafx_MCD_crud_tableview;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseEvent;
import models.Order;

/**
 * FXML Controller class
 *
 * @author user
 */
public class CrudMCDTableViewController implements Initializable {

    @FXML
    private TextField queryID;
    @FXML
    private TextField queryName;
    @FXML
    private TableView<Order> table_student;
    @FXML
    private TableColumn<Order, String> col_id;
    @FXML
    private TableColumn<Order, String> col_name;
    @FXML
    private TableColumn<Order, String> col_phone;
    @FXML
    private TableColumn<Order, String> col_address;
    @FXML
    private TextArea dispalyCourse;
    @FXML
    private Pagination pagination;

    private List<Order> orders = new ArrayList();
    private customerDAO customerdao = new customerDAO();
    //表格的每一頁顯示幾個rows
    private final int RowsPerPage = 8;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initTable(); //表格初始化
    }

    private void initTable() {

        //表格最後一欄是空白，不要顯示!
        table_student.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        //table_student.setPrefHeight(200);
        col_id.setCellValueFactory(new PropertyValueFactory<>("order_num"));
        col_name.setCellValueFactory(new PropertyValueFactory<>("customer_name"));
        col_address.setCellValueFactory(new PropertyValueFactory<>("customer_address"));
        col_phone.setCellValueFactory(new PropertyValueFactory<>("customer_phone"));

        //按下頁次會驅動的事件，寫法格式有點難理解，說明如後:
        //ObservableValue<? extends Number> 是介面，
        // ? extends Number 表示某種型態繼承Number類別  ?表示此型態沒被用到所以用?代替
        // changed 有三個參數: ObservableValue、舊的頁次、新的頁次
        // ObservableValue是頁次物件的一些屬性 印出如下的結果:
        //IntegerProperty [bean: Pagination[id=pagination, styleClass=pagination], name: currentPageIndex, value: 1]
          pagination.currentPageIndexProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                showTablePage(newValue.intValue(), RowsPerPage);
                //System.out.println(observable);
            }
        });

        // 表格切換到一下筆，對應的驅動方法，此處暫時沒用到，寫法與前面類似
        table_student.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                System.out.println(newValue);
            }
        });

        //讓表格內容可以修改
        table_student.setEditable(true);
        //表格欄位設定成可以編輯必須分別塞入一個TextFieldTableCell類別元件
        col_id.setCellFactory(TextFieldTableCell.forTableColumn());
        col_name.setCellFactory(TextFieldTableCell.forTableColumn());
        col_address.setCellFactory(TextFieldTableCell.forTableColumn());
        col_phone.setCellFactory(TextFieldTableCell.forTableColumn());
        /*
        //學生學號欄位若有修改驅動這個方法
        col_id.setOnEditCommit(new EventHandler<CellEditEvent<Order, String>>() {
            @Override
            public void handle(CellEditEvent<Order, String> event) {
                //拿到表格中所在的該筆紀錄(是一筆學生物件)
                Order stud = table_student.getSelectionModel().getSelectedItem();
                stud.setOrder_num(event.getNewValue()); //將該筆學生物件修改成新的值
            }
        });
         */
        //學生姓名欄位若有修改驅動這個方法
        col_name.setOnEditCommit(new EventHandler<CellEditEvent<Order, String>>() {
            @Override
            public void handle(CellEditEvent<Order, String> event) {
                //取得該筆紀錄的方式有以下3種寫法:
                //Student stud = event.getTableView().getItems().get(event.getTablePosition().getRow());
                //Student stud = (Student) event.getTableView().getItems().get(event.getTablePosition().getRow());
                Order stud = table_student.getSelectionModel().getSelectedItem();
                System.out.println(event.getNewValue());
                stud.setCustomer_name(event.getNewValue());
                //也可這樣更新新值寫法2:
                //((Student) event.getTableView().getItems().get(event.getTablePosition().getRow())).setName(t.getNewValue());
            }
        });
        //學生電話欄位若有修改驅動這個方法
        col_phone.setOnEditCommit(new EventHandler<CellEditEvent<Order, String>>() {
            @Override
            public void handle(CellEditEvent<Order, String> event) {
                Order stud = table_student.getSelectionModel().getSelectedItem();
                stud.setCustomer_phone(event.getNewValue());
            }
        });
//學生電話欄位若有修改驅動這個方法
        col_address.setOnEditCommit(new EventHandler<CellEditEvent<Order, String>>() {
            @Override
            public void handle(CellEditEvent<Order, String> event) {
                Order stud = table_student.getSelectionModel().getSelectedItem();
                stud.setCustomer_address(event.getNewValue());
            }
        });
    }

    //表格內容載入
    private void loadTable() {
        int totalPage = (int) (Math.ceil(orders.size() * 1.0 / RowsPerPage));
        pagination.setPageCount(totalPage);
        //pagination.setCurrentPageIndex(0);
        int currentpg = pagination.getCurrentPageIndex();
        showTablePage(currentpg, RowsPerPage);
    }

    //顯示某一個頁面的表格內容
    private void showTablePage(int pg, int row_per_pg) {
        table_student.getItems().clear(); //先清除表格內容
        int from = pg * row_per_pg;  //計算在此頁面顯示第幾筆到第幾筆
        int to = Math.min(from + row_per_pg, orders.size());
        //students一筆一筆加到表格中
        for (int i = from; i < to; i++) {
            table_student.getItems().add(orders.get(i));
        }
    }

    @FXML
    private void update(ActionEvent event) {
        Order stud = table_student.getSelectionModel().getSelectedItem();
        String id = stud.getOrder_num();
        String name = stud.getCustomer_name();
        String phone = stud.getCustomer_phone();
        String address = stud.getCustomer_address();
        customerdao.update(new Order(id, name, address, phone));
        orders = customerdao.getAllStudents();
        loadTable();

    }

    @FXML
    private void delete(ActionEvent event) {
        Order stud = table_student.getSelectionModel().getSelectedItem();
        String id = stud.getOrder_num();

        boolean sucess = customerdao.delete(id);
        orders = customerdao.getAllStudents();
        loadTable();

    }

    @FXML
    private void insert(ActionEvent event) {
        Order stud = table_student.getSelectionModel().getSelectedItem();
        String id = stud.getOrder_num();
        String name = stud.getCustomer_name();
        String phone = stud.getCustomer_phone();
        String address = stud.getCustomer_address();
        customerdao.add(new Order(id, name, address, phone));
        orders = customerdao.getAllStudents();
        loadTable();
    }

    @FXML
    private void blankRecord(ActionEvent event) {
        String order_num = customerdao.getMaxOrderNum();
        if (order_num == null) {
            order_num = "ord-num-100";
        }
        int serial_num = Integer.parseInt(order_num.split("-")[2]) + 1;
        String new_order_num = "ord-num-" + serial_num;
        table_student.getItems().add(new Order(new_order_num, "李大同?", "高雄?", "09?"));
    }

    @FXML
    private void findID(ActionEvent event) {
        orders.clear();
        orders.add(customerdao.selectByID(queryID.getText()));
        loadTable();
    }

    @FXML
    private void findName(ActionEvent event) {
        //stdao.selectByName(queryName.getText());
        orders = customerdao.selectByName(queryName.getText());
        loadTable();

    }

    @FXML
    private void findAll(ActionEvent event) {
        List<Order> allorder = customerdao.getAllStudents();
        customerdao.getAllStudents();

        orders = customerdao.getAllStudents();
        
        //若students是ObservableList<Student>要這樣寫才可行:
        //students.addAll( stdao.getAllStudents()); 
        loadTable();

    }

    @FXML
    private void selectAllCourses(ActionEvent event) {

    }

}
