-- --------------------------------------------------------
-- 主機:                           127.0.0.1
-- 伺服器版本:                        10.5.9-MariaDB - mariadb.org binary distribution
-- 伺服器作業系統:                      Win64
-- HeidiSQL 版本:                  11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- 傾印 db_pos 的資料庫結構
CREATE DATABASE IF NOT EXISTS `db_pos` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `db_pos`;

-- 傾印  資料表 db_pos.order_data 結構
CREATE TABLE IF NOT EXISTS `order_data` (
  `order_id` varchar(20) NOT NULL,
  `product_id` varchar(50) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 正在傾印表格  db_pos.order_data 的資料：~8 rows (近似值)
/*!40000 ALTER TABLE `order_data` DISABLE KEYS */;
INSERT INTO `order_data` (`order_id`, `product_id`, `price`, `quantity`) VALUES
	('ord-id-101', 'p-d-101', 32, 2),
	('ord-id-101', 'p-d-102', 42, 1),
	('ord-id-102', 'p-m-007', 72, 1),
	('ord-id-102', 'p-d-103', 55, 1),
	('ord-id-102', 'p-t-204', 40, 1),
	('ord-id-103', 'p-m-001', 72, 3),
	('ord-id-103', 'p-d-103', 55, 1),
	('ord-id-103', 'p-t-204', 40, 1);
/*!40000 ALTER TABLE `order_data` ENABLE KEYS */;

-- 傾印  資料表 db_pos.order_detail 結構
CREATE TABLE IF NOT EXISTS `order_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_num` varchar(20) NOT NULL,
  `order_id` varchar(20) NOT NULL,
  `total` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_id` (`order_id`),
  KEY `FK_order_detail_sale_order` (`order_num`),
  CONSTRAINT `FK_order_detail_order_data` FOREIGN KEY (`order_id`) REFERENCES `order_data` (`order_id`),
  CONSTRAINT `FK_order_detail_sale_order` FOREIGN KEY (`order_num`) REFERENCES `sale_order` (`order_num`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4;

-- 正在傾印表格  db_pos.order_detail 的資料：~2 rows (近似值)
/*!40000 ALTER TABLE `order_detail` DISABLE KEYS */;
INSERT INTO `order_detail` (`id`, `order_num`, `order_id`, `total`) VALUES
	(116, 'ord-num-103', 'ord-id-101', 106),
	(117, 'ord-num-104', 'ord-id-102', 167),
	(118, 'ord-num-105', 'ord-id-103', 311);
/*!40000 ALTER TABLE `order_detail` ENABLE KEYS */;

-- 傾印  資料表 db_pos.product 結構
CREATE TABLE IF NOT EXISTS `product` (
  `product_id` varchar(20) NOT NULL,
  `category` varchar(50) NOT NULL,
  `name` varchar(150) NOT NULL,
  `price` int(11) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 正在傾印表格  db_pos.product 的資料：~29 rows (近似值)
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` (`product_id`, `category`, `name`, `price`, `photo`, `description`) VALUES
	('p-d-101', '點心', '薯條(小)', 32, 'Fries-S.jpg', '產品描述'),
	('p-d-102', '點心', '薯條(中)', 42, 'fries-mid.jpg', '產品描述'),
	('p-d-103', '點心', '薯條(大)', 55, 'fries-big.jpg', '產品描述'),
	('p-d-104', '點心', '薯餅', 32, 'hash-browns.jpg', '產品描述'),
	('p-d-105', '點心', '蘋果派', 32, 'applepie.jpg', '產品描述'),
	('p-d-106', '點心', '冰炫風', 55, 'mcflurry-oreo.jpg', '產品描述'),
	('p-d-107', '點心', '蛋捲冰淇淋', 18, 'ice-cream-cone.jpg', '產品描述'),
	('p-m-001', '主餐', '大麥克', 72, 'EVM-01-Big-Mac.jpg', '產品描述'),
	('p-m-002', '主餐', '雙層牛肉吉事堡', 62, 'EVM-02-D-Cheeseburger.jpg', '產品描述'),
	('p-m-003', '主餐', '嫩煎雞腿堡', 82, 'EVM-04-GBC.jpg', '產品描述'),
	('p-m-004', '主餐', '麥香雞', 44, 'EVM-05-McChicken.jpg', '產品描述'),
	('p-m-005', '主餐', '麥克雞塊 (6塊)', 60, 'EVM-06-NGT6.jpg', '產品描述'),
	('p-m-006', '主餐', '麥克雞塊 (10塊)', 100, 'EVM-06-NGT10.jpg', '產品描述'),
	('p-m-007', '主餐', '勁辣雞腿堡', 72, 'EVM-08-SCF.jpg', '產品描述'),
	('p-m-008', '主餐', '麥脆雞腿 (2塊)', 110, 'EVM-09-MFC.jpg', '產品描述'),
	('p-m-009', '主餐', '麥脆雞翅 (2塊)', 90, 'EVM-10-MFC.jpg', '產品描述'),
	('p-m-010', '主餐', '麥香魚', 44, 'EVM-12-FOF.jpg', '產品描述'),
	('p-m-011', '主餐', '薑燒豬肉長堡', 74, 'Ginger-pork-long-burger.jpg', '產品描述'),
	('p-m-012', '主餐', '煙燻雞肉長堡', 74, 'Smoked-chicken-long-burger.jpg', '產品描述'),
	('p-m-013', '主餐', 'BLT 安格斯黑堡', 109, 'signature-blt-beef.jpg', '產品描述'),
	('p-m-014', '主餐', 'BLT 辣脆雞腿堡', 109, 'signature-blt-fried-chicken.jpg', '產品描述'),
	('p-m-015', '主餐', 'BLT 嫩煎雞腿堡', 109, 'signature-blt-grilled-chicken.jpg', '產品描述'),
	('p-m-016', '主餐', '蕈菇安格斯黑堡', 119, 'signature-mushroom-beef.jpg', '產品描述'),
	('p-m-017', '點心', '??漢堡', 100, 'xxx.jpg', '風味獨特'),
	('p-t-201', '茶飲', '紅茶(檸檬風味)', 40, 'iced-black-tea-lemonflavored.jpg', '產品描述'),
	('p-t-202', '茶飲', '綠茶(無糖)', 40, 'iced-green-tea-sugarfree.jpg', '產品描述'),
	('p-t-203', '茶飲', '玉米濃湯', 52, 'corn-soup-small.jpg', '產品描述'),
	('p-t-204', '茶飲', '可口可樂', 40, 'coca-cola.jpg', '產品描述'),
	('p-t-205', '茶飲', '雪碧', 40, 'sprite.jpg', '產品描述'),
	('p-t-206', '茶飲', '特選黑咖啡', 65, 'americano-hot.jpg', '產品描述');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;

-- 傾印  資料表 db_pos.sale_order 結構
CREATE TABLE IF NOT EXISTS `sale_order` (
  `order_num` varchar(20) NOT NULL,
  `order_date` datetime DEFAULT current_timestamp(),
  `customer_name` varchar(150) DEFAULT NULL,
  `customer_address` varchar(250) DEFAULT NULL,
  `customer_phone` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`order_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 正在傾印表格  db_pos.sale_order 的資料：~4 rows (近似值)
/*!40000 ALTER TABLE `sale_order` DISABLE KEYS */;
INSERT INTO `sale_order` (`order_num`, `order_date`, `customer_name`, `customer_address`, `customer_phone`) VALUES
	('ord-num-101', '2021-05-04 22:54:47', '王範例', '高雄市楠梓區大學路一號', '093256789'),
	('ord-num-102', '2021-05-04 22:55:19', '王範例', '高雄市楠梓區大學路一號', '093256789'),
	('ord-num-103', '2021-06-21 15:06:05', '王範例', '高雄市楠梓區大學路一號', '093256789'),
	('ord-num-104', '2021-06-21 15:07:19', '沈文鑫', '高雄市楠梓區大學路一號', '無電話'),
	('ord-num-105', '2021-06-23 10:29:09', '沈文鑫', '高雄市楠梓區大學路一號', '093256789');
/*!40000 ALTER TABLE `sale_order` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
